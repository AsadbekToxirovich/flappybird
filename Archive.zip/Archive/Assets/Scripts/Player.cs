using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5.0f; // Control the speed
    private Rigidbody2D rb;
    public bool isDead = false;

    // Audio clips
    public AudioClip flySound; // Sound for flying
    public AudioClip passObstacleSound; // Sound for passing through obstacles
    public AudioClip gameOverSound; // Sound for game over

    private AudioSource audioSource;

    void Start()
    {
        // Get Rigidbody2D Component
        rb = GetComponent<Rigidbody2D>();
        audioSource = gameObject.AddComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {
        // Check if the left mouse button is pressed
        if (Input.GetMouseButtonDown(0) && !isDead)
        {
            rb.velocity = Vector2.up * speed;
            PlaySound(flySound);
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        isDead = true;
        PlaySound(gameOverSound);
        // You can also handle game over logic here
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        // Assuming obstacles are tagged as "Obstacle"
        if (other.CompareTag("Obstacle"))
        {
            PlaySound(passObstacleSound);
            // Logic for passing through obstacles can go here
        }
    }

    private void PlaySound(AudioClip clip)
    {
        if (clip != null)
        {
            audioSource.PlayOneShot(clip);
        }
    }
}
